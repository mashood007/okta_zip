


class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable,:saml_authenticatable

  attr_accessor :login
  after_create :create_user_account_in_okta

  def create_user_account_in_okta
     puts "*************self---"+self.inspect   
      require 'net/http'
      require 'uri'
      require 'json'
      
      uri = URI.parse("https://dev-561752.okta.com/api/v1/users?activate=false")
      request = Net::HTTP::Post.new(uri)
      request.content_type = "application/json"
      request["Accept"] = "application/json"
      request["Authorization"] = "SSWS 00L4Ml6fqcWqZQ-pCk-2i-KuNzojeJ7vOMKjZvPDLx"
      
      request.body = JSON.dump({
        "profile" => {
          "firstName" => "Test",
          "lastName" => "tester",
          "email" => self.email,
          "login" => self.email,
          "mobilePhone" => "555-415-1339",
          "tenant_id" => "1",
          "user_role" => "4"
        },
        "credentials" => {
          "password" => {
            "hash" => {
              "algorithm" => "BCRYPT",
              "workFactor" => 10,
              "salt" => "rwh3vH166HCH/NT9XV5FYu",
              "value" => self.encrypted_password
            }
          }
        }
      })
# 
         
#      request.body = JSON.dump({
#        "profile" => {
#          "firstName" => "tester",
#          "lastName" => "j",
#          "email" => self.email,
#          "login" => self.email,
#          "mobilePhone" => "555-415-1338",
#          "tenant_id" => "1"
#        }
#      })   
      
      req_options = {
        use_ssl: uri.scheme == "https",
      }
            
      response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
        http.request(request)
      end
      
      # response.code
      # response.body

  end

  def login=(login)
    @login = login
  end
  

  def login
    @login || self.user_id || self.email
  end

require 'devise/orm/active_record'
  def self.saml_config_devise
    Devise.setup do |config|  
      config.saml_create_user = true
      config.saml_update_user = true
      config.saml_default_user_key = :email
      config.saml_session_index_key = :session_index
      config.saml_use_subject = true
      config.idp_settings_adapter = nil
      config.saml_configure do |settings|
        settings.assertion_consumer_service_url     = "http://localhost:3000/users/saml/auth"
      settings.protocol_binding = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
      settings.name_identifier_format             = "urn:oasis:names:tc:SAML:2.0:nameid-format:transient"
      settings.issuer                             = "http://localhost:3000/users/saml/metadata"
      settings.authn_context                      = "urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport"
      settings.idp_slo_target_url                 = ""

      #line configuration
      settings.idp_sso_target_url                 = "https://dev-561752.okta.com/app/maxxionsystemsdev561752_samlsample_1/exk16uwzx0Zu0fSB2357/sso/saml"
      settings.idp_cert_fingerprint               = '3A:F9:3C:37:99:94:B8:52:F3:B4:A4:B9:57:D6:0E:66:A5:0D:C6:CF:DB:C6:BE:E5:1F:1F:92:8E:C1:71:43:E2'
      settings.idp_cert_fingerprint_algorithm     = 'http://www.w3.org/2000/09/xmldsig#sha256'
      end
    end
  end

  def self.find_for_database_authentication(warden_conditions)
    conditions = warden_conditions.dup
    if login = conditions.delete(:login)
      where(conditions.to_h).where(["user_id = :value OR email = :value", { :value => login.downcase }]).first
    else
      where(conditions.to_h).first
    end
  end

  def send_devise_notification(notification, *args)
    devise_mailer.send(notification, self, *args).deliver_later
  end
  



end
