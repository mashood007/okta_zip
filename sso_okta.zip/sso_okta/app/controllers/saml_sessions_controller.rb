class UserSessionsController < Devise::SamlSessionsController
  before_filter :user_unread
  
  def user_unread
	puts "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
  end
  
  
end
