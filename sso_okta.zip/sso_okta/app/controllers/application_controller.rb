      require 'net/http'
      require 'uri'
      require 'json'

class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

 # before_action :configure_permitted_parameters, if: :devise_controller?
  before_action :set_saml
 # before_action :send_saml
  protected


  def send_saml

      
      uri = URI.parse("https://dev-561752.okta.com/api/v1/users?activate=false")
      request = Net::HTTP::Post.new(uri)
      request.content_type = "application/json"
      request["Accept"] = "application/json"
      request["Authorization"] = "SSWS 00L4Ml6fqcWqZQ-pCk-2i-KuNzojeJ7vOMKjZvPDLx"
      
      request.body = JSON.dump({
        "profile" => {
          "firstName" => "swapna",
          "lastName" => "j",
          "email" => "swapna.j@example.com",
          "login" => "swapna.j@example.com",
          "mobilePhone" => "555-415-1337",
          "tenant_id" => "1"
        }
      })
      
      req_options = {
        use_ssl: uri.scheme == "https",
      }
      
      response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
        http.request(request)
      end
      
      # response.code
      # response.body



  end


  def set_saml
    User.saml_config_devise
  end
end
