
Devise.setup do |config|
  config.mailer_sender = 'please-change-me-at-config-initializers-devise@example.com'

  require 'devise/orm/active_record'

  config.case_insensitive_keys = [:email]


  config.strip_whitespace_keys = [:email]


  config.skip_session_storage = [:http_auth]

  config.stretches = Rails.env.test? ? 1 : 11




  config.reconfirmable = true


  config.expire_all_remember_me_on_sign_out = true

  config.password_length = 6..128


  config.email_regexp = /\A[^@\s]+@[^@\s]+\z/


  config.sign_out_via = :delete
#Devise.setup do |config|  
#      config.saml_create_user = false
#      config.saml_update_user = true
#      config.saml_default_user_key = :email
#      config.saml_session_index_key = :session_index
#      config.saml_use_subject = true
#      config.idp_settings_adapter = nil
#      config.saml_configure do |settings|
#        settings.assertion_consumer_service_url     = "http://localhost:3000/users/saml/auth"
#      settings.protocol_binding = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
#      settings.name_identifier_format             = "urn:oasis:names:tc:SAML:2.0:nameid-format:transient"
#      settings.issuer                             = "http://localhost:3000/users/saml/metadata"
#      settings.authn_context                      = "urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport"
#      settings.idp_slo_target_url                 = ""
#
#      #line configuration
#      settings.idp_sso_target_url                 = "https://dev-561752.okta.com/app/maxxionsystemsdev561752_samlsample_1/exk16uwzx0Zu0fSB2357/sso/saml"
#      settings.idp_cert_fingerprint               = '3A:F9:3C:37:99:94:B8:52:F3:B4:A4:B9:57:D6:0E:66:A5:0D:C6:CF:DB:C6:BE:E5:1F:1F:92:8E:C1:71:43:E2'
#      settings.idp_cert_fingerprint_algorithm     = 'http://www.w3.org/2000/09/xmldsig#sha256'
#      end
#    end

end

